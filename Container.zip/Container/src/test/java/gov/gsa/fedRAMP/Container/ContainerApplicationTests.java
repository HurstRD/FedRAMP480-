package gov.gsa.fedRAMP.Container;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ContainerApplicationTests {

	@Test
	void contextLoads() {
	}

}
